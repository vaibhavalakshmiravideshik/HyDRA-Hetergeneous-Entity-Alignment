"""
HyDRA — Main Entry Point
========================
Run zero-shot, supervised, or baseline evaluation on any of the
three heterogeneous biomedical EA benchmarks.

Usage (from repo root OR from inside hydra/):
    python run_hydra.py --mode all
    python run_hydra.py --mode zeroshot
    python run_hydra.py --mode supervised
    python run_hydra.py --mode baselines

Environment variables required for LLM stages:
    AZURE_OPENAI_KEY   — Azure OpenAI API key
    AZURE_OPENAI_URL   — Azure OpenAI endpoint URL

Or pass directly:
    python run_hydra.py --azure_key <key> --azure_url <url>
"""

# ── Path fix: allow running from repo root OR from inside hydra/ ──────────────
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# ─────────────────────────────────────────────────────────────────────────────

import argparse
from pathlib import Path

from config import DATASETS, BGE_PREFIX, ENCODER, CACHE_DIR, LLM_MODEL
from utils.helpers import get_llm_client, build_label_map
from utils.data_loader import load_all_datasets
from stage1.rotate_families import run_stage1
from stage2.profiling import run_stage2
from stage3.retrieval import run_stage3
from stage4.reranking import run_stage4
from stage5.supervised import run_stage5


# ── API key check ─────────────────────────────────────────────────────────────

def check_api_credentials(azure_key: str, azure_url: str, mode: str):
    """
    Fail fast with a clear message if LLM credentials are missing
    and the requested mode requires them.
    """
    llm_modes = {"all", "zeroshot"}
    if mode not in llm_modes:
        return  # baselines and supervised don't need LLM

    key = azure_key or os.environ.get("AZURE_OPENAI_KEY", "")
    url = azure_url or os.environ.get("AZURE_OPENAI_URL", "")

    if not key or not url:
        missing = []
        if not key:
            missing.append("AZURE_OPENAI_KEY")
        if not url:
            missing.append("AZURE_OPENAI_URL")
        raise EnvironmentError(
            f"\n\nMissing required API credentials: {', '.join(missing)}\n"
            f"Set them as environment variables:\n"
            f"  export AZURE_OPENAI_KEY='your_key'\n"
            f"  export AZURE_OPENAI_URL='your_endpoint'\n"
            f"Or pass via --azure_key and --azure_url arguments.\n"
            f"See .env.example for reference.\n"
        )


# ── CLI ───────────────────────────────────────────────────────────────────────

def parse_args():
    p = argparse.ArgumentParser(description="HyDRA biomedical entity alignment")
    p.add_argument("--mode", choices=["all", "zeroshot", "supervised", "baselines"],
                   default="all",
                   help="Which pipeline stages to run (default: all)")
    p.add_argument("--datasets", nargs="+",
                   choices=list(DATASETS.keys()),
                   default=list(DATASETS.keys()),
                   help="Which datasets to run (default: all three)")
    p.add_argument("--cache_dir", default=CACHE_DIR,
                   help=f"Directory for cached pkl files (default: {CACHE_DIR})")
    p.add_argument("--azure_key", default=None,
                   help="Azure OpenAI API key (overrides env var)")
    p.add_argument("--azure_url", default=None,
                   help="Azure OpenAI endpoint URL (overrides env var)")
    p.add_argument("--device", default="cuda",
                   help="PyTorch device: 'cuda' or 'cpu' (default: cuda)")
    p.add_argument("--oracle_gate", action="store_true", default=True,
                   help="Use oracle LLM gate (upper bound; default: True)")
    p.add_argument("--lex_threshold", type=float, default=1.0,
                   help="Deployable lex confidence threshold for LLM gate")
    return p.parse_args()


# ── Main ──────────────────────────────────────────────────────────────────────

def main():
    args = parse_args()

    # Early credential check — fail fast before downloading anything
    check_api_credentials(args.azure_key, args.azure_url, args.mode)

    cache_dir = args.cache_dir
    Path(cache_dir).mkdir(parents=True, exist_ok=True)

    # Filter to requested datasets
    datasets_cfg = {k: v for k, v in DATASETS.items()
                    if k in args.datasets}

    print(f"\nHyDRA — mode={args.mode}  datasets={list(datasets_cfg.keys())}")
    print(f"cache_dir={cache_dir}  device={args.device}\n")

    # Load datasets
    print("Loading datasets from HuggingFace...")
    raw = load_all_datasets(datasets_cfg)

    # Build global label map (populated after Stage 2 roles are known,
    # but seeded here with empty sets so helpers.resolve() has a map)
    uri2label, _, _ = build_label_map(raw, set(), set(), set())

    # LLM client (only needed for zeroshot/all modes)
    client, model = get_llm_client(args.azure_key, args.azure_url, LLM_MODEL)

    # ── Stage 1: Relation Family Induction ───────────────────────────────────
    rotate_results, family_mappings = run_stage1(
        raw, datasets_cfg, cache_dir, client, model, device=args.device)

    # ── Stage 2: Entity Profiling ─────────────────────────────────────────────
    all_profiles = run_stage2(
        raw, rotate_results, datasets_cfg,
        cache_dir, client, model, uri2label)

    if args.mode == "baselines":
        print("\nBaseline-only mode: stages 1-2 complete. Exiting.")
        return

    # ── Stage 3: BGE Retrieval ────────────────────────────────────────────────
    bge_embs, zeroshot_bge, incorrect_bge = run_stage3(
        all_profiles, raw, cache_dir, BGE_PREFIX,
        encoder_name=ENCODER, device=args.device)

    if args.mode in ("all", "zeroshot"):
        # ── Stage 4: Lex + LLM Reranking ─────────────────────────────────────
        reranked, llm_preds, final_metrics = run_stage4(
            all_profiles, incorrect_bge, raw, cache_dir,
            client, model,
            oracle_gate=args.oracle_gate,
            lex_threshold=args.lex_threshold)

        print("\n" + "=" * 60)
        print("Final zero-shot results:")
        print("=" * 60)
        for ds, m in final_metrics.items():
            print(f"  {ds}: H@1={m['hits1']:.4f}  H@5={m['hits5']:.4f}  "
                  f"H@10={m['hits10']:.4f}  MRR={m['mrr']:.4f}")

    if args.mode in ("all", "supervised"):
        # ── Stage 5: Supervised Fine-tuning ──────────────────────────────────
        run_stage5(raw, datasets_cfg, cache_dir, device=args.device)


if __name__ == "__main__":
    main()
